Mystery In the Files (100 pts)

Extract the archive and you'll find 50 files in forensic_files/. Each file contains a base64 string.
One file's base64 is corrupted and contains the FLAG near the end of the file.

FLAG format: POLIJE{...}

Hints:
 - Try decoding files with a script or `base64 -d`.
 - For the corrupted file, inspect it manually (e.g., open with a text editor) to find the FLAG.

Good luck!
