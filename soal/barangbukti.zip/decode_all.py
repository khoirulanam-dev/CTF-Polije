#!/usr/bin/env python3
import base64, pathlib

d = pathlib.Path('forensic_files')
for p in sorted(d.iterdir()):
    txt = p.read_text(errors='ignore').strip()
    try:
        dec = base64.b64decode(txt, validate=True)
        print(p.name, '->', dec.decode(errors='replace'))
    except Exception as e:
        print(p.name, '->', 'decode error:', e)
        # show a short preview
        print('  preview:', txt[:120])
