/*
 * arch_backdoor.c
 *
 * Benign example kernel module for CTF:
 * - Creates /proc/arch_whisper
 * - When read, decodes an XOR-obfuscated flag and returns it to userspace.
 *
 * Important: This module is intentionally non-malicious and only demonstrates
 * a hidden resource inside a kernel module for forensic/reverse tasks.
 *
 * To change flag: modify FLAG_XORED and FLAG_LEN below and rebuild.
 *
 * Build:
 *   make
 * Insert:
 *   sudo insmod arch_backdoor.ko
 * Check:
 *   lsmod | grep arch_backdoor
 *   sudo cat /proc/arch_whisper
 * Remove:
 *   sudo rmmod arch_backdoor
 *
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>

#define PROC_NAME "arch_whisper"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("CTF: benign example");
MODULE_DESCRIPTION("Benign kernel module that exposes an XOR-obfuscated flag in /proc");
MODULE_VERSION("0.1");

/* --- MODIFY THIS BEFORE EVENT (admin) ---
 * Put the XORed bytes of your flag here and update FLAG_LEN.
 * Example: original flag "POLIJE{EXAMPLE_FLAG_1}" XORed with 0xAA:
 * Compute bytes and paste here.
 *
 * For this distributed package a sample flag is used:
 *   POLIJE{KERNEL_WHISPER_7f4b}
 * XOR key: 0xAA
 * ------------------------------------------------
 */
static const unsigned char FLAG_XORED[] = {
    0xfa,0xe5,0xe6,0xe3,0xe0,0xef,0xd1,0xf8,0x9d,0xf2,0x98,0xe1,0x93,0xe7,0x9e,0xe8,0x92,0xf0,0x9b,0xd7
};
static const unsigned int FLAG_LEN = 20;
static const unsigned char XOR_KEY = 0xAA;

static struct proc_dir_entry *proc_entry;

/* read routine: copies decoded flag into userspace buffer */
static ssize_t proc_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
    unsigned char decoded[128];
    unsigned int i;
    size_t len;

    if (*ppos > 0) /* already read */
        return 0;

    if (FLAG_LEN + 1 > sizeof(decoded))
        return -EINVAL;

    for (i = 0; i < FLAG_LEN; i++) {
        decoded[i] = FLAG_XORED[i] ^ XOR_KEY;
    }
    decoded[FLAG_LEN] = '\\n';
    len = FLAG_LEN + 1;

    if (copy_to_user(buf, decoded, len))
        return -EFAULT;

    *ppos = len;
    return len;
}

/* file ops setup */
static const struct proc_ops proc_file_ops = {
    .proc_read = proc_read,
};

static int __init arch_backdoor_init(void)
{
    proc_entry = proc_create(PROC_NAME, 0444, NULL, &proc_file_ops);
    if (!proc_entry) {
        pr_alert("arch_backdoor: failed to create /proc/%s\n", PROC_NAME);
        return -ENOMEM;
    }
    pr_info("arch_backdoor: module loaded, /proc/%s created\n", PROC_NAME);
    return 0;
}

static void __exit arch_backdoor_exit(void)
{
    proc_remove(proc_entry);
    pr_info("arch_backdoor: module removed, /proc/%s gone\n", PROC_NAME);
}

module_init(arch_backdoor_init);
module_exit(arch_backdoor_exit);
