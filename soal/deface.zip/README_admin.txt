Pemda-Kita Deface Investigation (HARD MODE)

Struktur:
- logs/access.log, access.log.1, error.log
- webroot/index.php, include.php, page/home.php, .htaccess
- webroot/uploads/shell.jpg (stegano webshell)
- webroot/uploads/.trash/00023 (deleted shell)
- cron/cleanup (persistence)
- screenshot/deface_screenshot.png (EXIF/text metadata flag)

Flag locations (untuk admin/writeup, JANGAN DIBERIKAN KE PESERTA):
1) POLIJE{sql_injection_log_artifact}  -> di error.log (SQL error leak)
2) POLIJE{ua_fingerprint_indoghost}    -> di access.log (User-Agent)
3) POLIJE{stegano_shell_exposed}       -> di appended PHP pada shell.jpg
4) POLIJE{deleted_shell_recovered}     -> di uploads/.trash/00023
5) POLIJE{final_flag_in_exif}          -> di metadata (Comment) deface_screenshot.png
