<?php
// Simplified vulnerable front controller
require_once 'include.php';

$id = isset($_GET['id']) ? $_GET['id'] : 1;

$conn = mysqli_connect('localhost','root','','pemda_portal');
if(!$conn){ die('db error'); }

$q = "SELECT title, content FROM news WHERE id = $id"; // vulnerable
$res = mysqli_query($conn, $q);
$row = mysqli_fetch_assoc($res);

?>
<!DOCTYPE html>
<html>
<head><title>Pemda-Kita Portal</title></head>
<body>
<h1><?php echo htmlspecialchars($row['title'] ?? 'Welcome'); ?></h1>
<div><?php echo $row['content'] ?? 'Berita belum tersedia.'; ?></div>
</body>
</html>
