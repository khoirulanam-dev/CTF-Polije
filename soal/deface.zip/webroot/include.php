<?php
// Insecure include, used via ?page=include.php&file=...
$file = isset($_GET['file']) ? $_GET['file'] : 'page/home';
$file = str_replace('..','',$file); // weak filter
include $file . '.php';
