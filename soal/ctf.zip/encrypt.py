"""
Pipeline enkripsi yang dipakai untuk challenge ini.
File ini TIDAK berisi flag asli, tapi menunjukkan urutan transformasi
sebelum nilai akhir dienkripsi dengan RSA.

Format flag: POLIJE{...}
"""

import json
from pathlib import Path

HERE = Path(__file__).parent

# --- bitwise layer ---

def _rot_byte(b: int, i: int) -> int:
    r = (3*i + 7) & 7
    return ((b << r) & 0xFF) | (b >> (8-r))

# --- weak hash & keystream ---

def _weak_hash(seed: bytes) -> int:
    v = 0x12345678
    for i, c in enumerate(seed):
        v = (v ^ (c + i*31)) & 0xFFFFFFFF
        v = ((v << 7) | (v >> 25)) & 0xFFFFFFFF
        v = (v * 0x45D9F3B) & 0xFFFFFFFF
    return v

def _keystream(password: str, length: int) -> bytes:
    s = _weak_hash(password.encode())
    out = bytearray()
    for _ in range(length):
        s = (1103515245 * s + 12345) & 0x7FFFFFFF
        out.append((s >> 7) & 0xFF)
    return bytes(out)

# --- charset + Vigenere-like layer ---

def _load_charset() -> str:
    return HERE.joinpath("charset.tbl").read_text(encoding="utf-8")

def _to_charset_layer(b: bytes, charset: str) -> str:
    L = len(charset)
    return ''.join(charset[x % L] for x in b)

def _vig_encrypt(text: str, charset: str, key: str) -> str:
    L = len(charset)
    idx = {c:i for i,c in enumerate(charset)}
    kidx = [idx[key[i % len(key)]] for i in range(len(key))]
    out = []
    for i,ch in enumerate(text):
        out.append(charset[(idx[ch] + kidx[i % len(kidx)]) % L])
    return ''.join(out)

# --- matrix XOR layer ---

def _load_matrix():
    raw = HERE.joinpath("matrix.bin").read_bytes()
    if len(raw) != 12*12:
        raise ValueError("matrix.bin ukuran tidak valid")
    mat = [raw[i*12:(i+1)*12] for i in range(12)]
    return mat

def _matrix_mix(data: bytes, matrix):
    out = bytearray(data)
    rows = len(matrix)
    cols = len(matrix[0])
    row_xor = [0]*rows
    for r in range(rows):
        v = 0
        for c in range(cols):
            v ^= matrix[r][c]
        row_xor[r] = v
    for i in range(len(out)):
        r = i % rows
        out[i] ^= row_xor[r]
    return bytes(out)

# --- custom Base62 layer ---

_BASE62 = "nospBQ59JMgSFVErH6G7TzWOXxIKRcDC41bU8N3hedu0Zik2tYvPAfajmqLlyw"

def _base62_encode_custom(data: bytes) -> bytes:
    alphabet = _BASE62
    L = len(alphabet)
    out_chars = []
    for i,b in enumerate(data):
        hi = (b >> 2) & 0x3F
        lo = ((b & 0x3) << 4) ^ (i & 0x0F)
        out_chars.append(alphabet[hi % L])
        out_chars.append(alphabet[lo % L])
    return ''.join(out_chars).encode('ascii')

def encrypt_pipeline(plaintext: bytes) -> bytes:
    # Layer 1: bit rotation
    step1 = bytes(_rot_byte(b,i) for i,b in enumerate(plaintext))
    # Layer 2: XOR stream
    stream = _keystream("r@5a_t0k3n", len(step1))
    step2 = bytes(a ^ b for a,b in zip(step1, stream))
    # Layer 3: charset + Vigenere
    charset = _load_charset()
    txt = _to_charset_layer(step2, charset)
    step3 = _vig_encrypt(txt, charset, "R4SAXKEY")
    step3_bytes = step3.encode("utf-8")
    # Layer 4: matrix mix
    mat = _load_matrix()
    step4 = _matrix_mix(step3_bytes, mat)
    # Layer 5: custom Base62
    step5 = _base62_encode_custom(step4)
    return step5

if __name__ == "__main__":
    # Contoh penggunaan: ini hanya contoh, BUKAN flag asli.
    sample = b"POLIJE{dummy_example}"
    enc = encrypt_pipeline(sample)
    print("Sample encoded length:", len(enc))
    print("Sample encoded preview:", enc[:64])
