import crypto from "crypto";

function verifyToken(token, secret) {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [data, sig] = parts;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(data)
    .digest("hex");
  if (sig !== expected) return null;
  try {
    return JSON.parse(Buffer.from(data, "base64").toString("utf8"));
  } catch {
    return null;
  }
}

export async function GET(req) {
  try {
    const auth = (req.headers.get("authorization") || "").split(" ")[1];
    const secret = process.env.AUTH_SECRET || "dev_secret";
    const payload = verifyToken(auth, secret);
    if (!payload)
      return new Response(
        JSON.stringify({ success: false, message: "auth required" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );

    // in-memory docs "database"
    const docs = [
      {
        id: "100",
        ownerId: 10,
        title: "Alice Public",
        access_code_md5: "5f4dcc3b5aa765d61d8327deb882cf99",
      }, // md5("password")
      {
        id: "200",
        ownerId: 11,
        title: "Bob Secret",
        access_code_md5: "e99a18c428cb38d5f260853678922e03",
      }, // md5("abc123")
      {
        id: "999",
        ownerId: 42,
        title: "Admin Secret",
        access_code_md5:
          process.env.DOC_SECRET_MD5 || "d41d8cd98f00b204e9800998ecf8427e",
      }, // maybe env
    ];

    // BUG: returns hashed access codes to any logged-in user
    return new Response(JSON.stringify({ success: true, docs }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ success: false }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
