import crypto from "crypto";

function sign(payload, secret) {
  const data = Buffer.from(JSON.stringify(payload)).toString("base64");
  const sig = crypto.createHmac("sha256", secret).update(data).digest("hex");
  return `${data}.${sig}`;
}

export async function POST(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const username = (body.username || "guest").toString();
    const users = [
      { id: 10, username: "alice" },
      { id: 11, username: "bob" },
      { id: 1, username: "guest" },
    ];
    const user = users.find((u) => u.username === username) || {
      id: 1,
      username: "guest",
    };

    const secret = process.env.AUTH_SECRET || "dev_secret";
    const token = sign({ userId: user.id, username: user.username }, secret);

    return new Response(JSON.stringify({ success: true, token }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ success: false }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
