// src/app/api/docs/[id]/route.js
import crypto from "crypto";

function verifyToken(token, secret) {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [data, sig] = parts;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(data)
    .digest("hex");
  if (sig !== expected) return null;
  try {
    return JSON.parse(Buffer.from(data, "base64").toString("utf8"));
  } catch {
    return null;
  }
}

function md5(str) {
  return crypto.createHash("md5").update(str).digest("hex");
}

export async function GET(req, ctx) {
  // ✅ Next.js 14–15: ctx.params is a Promise
  const { id } = await ctx.params;

  try {
    const auth = (req.headers.get("authorization") || "").split(" ")[1];
    const secret = process.env.AUTH_SECRET || "dev_secret";
    const user = verifyToken(auth, secret);

    if (!user) {
      return new Response(
        JSON.stringify({ success: false, message: "auth required" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }

    // Database tiruan
    const docs = {
      100: {
        id: "100",
        ownerId: 10,
        content: "Alice doc",
        access_code_md5: "5f4dcc3b5aa765d61d8327deb882cf99",
      },
      200: {
        id: "200",
        ownerId: 11,
        content: "Bob doc",
        access_code_md5: "e99a18c428cb38d5f260853678922e03",
      },
      999: {
        id: "999",
        ownerId: 42,
        content: `Admin page: FLAG => ${
          process.env.CTF_FLAG || "POLIJE{layered_idor_v1!}"
        }`,
        access_code_md5:
          process.env.DOC_SECRET_MD5 || "098f6bcd4621d373cade4e832627b4f6", // md5("test")
      },
    };

    const doc = docs[id];
    if (!doc) {
      return new Response(
        JSON.stringify({ success: false, message: "not found" }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    // Jika owner cocok
    if (user.userId === doc.ownerId) {
      return new Response(JSON.stringify({ success: true, doc }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Jika bukan owner → perlu access code
    const code = req.headers.get("x-access-code") || "";
    if (!code) {
      return new Response(
        JSON.stringify({ success: false, message: "missing access code" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    // Cek MD5 access code
    if (md5(code) === doc.access_code_md5) {
      return new Response(JSON.stringify({ success: true, doc }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ success: false, message: "bad code" }),
      { status: 403, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error(err);
    return new Response(
      JSON.stringify({ success: false, message: "server error" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
