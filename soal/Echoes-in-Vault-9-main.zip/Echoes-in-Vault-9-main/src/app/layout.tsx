// app/layout.tsx
import type { ReactNode } from "react";

export const metadata = {
  title: "Echoes in Vault 9",
  description: "Challenge CTF - Echoes in Vault 9",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          fontFamily:
            "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
          background: "#071026",
          color: "#e6eef8",
          minHeight: "100vh",
        }}
      >
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "2rem" }}>
          {children}
        </div>
      </body>
    </html>
  );
}
