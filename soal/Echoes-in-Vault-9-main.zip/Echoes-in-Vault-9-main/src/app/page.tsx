// app/page.tsx
export default function Page() {
  return (
    <main
      style={{
        display: "grid",
        placeItems: "center",
        minHeight: "80vh",
      }}
    >
      <section
        style={{
          width: "100%",
          maxWidth: 880,
          background: "#0b1220",
          borderRadius: 10,
          border: "1px solid #122437",
          padding: "2rem",
        }}
      >
        <h1 style={{ margin: 0, fontSize: "2.2rem" }}>Echoes in Vault 9</h1>

        <div style={{ marginTop: ".6rem", opacity: 0.85 }}>
          <p style={{ margin: 0 }}>
            Di lorong gelap, beberapa pintu terlihat sama. Satu terbuka hanya
            bagi mereka yang mampu membaca bayangan.
          </p>
        </div>

        <div
          style={{
            marginTop: "1.25rem",
            display: "flex",
            gap: ".75rem",
            alignItems: "center",
          }}
        >
          <div
            style={{
              padding: ".6rem .8rem",
              borderRadius: 8,
              background: "#071a2b",
              border: "1px solid #12324a",
              flex: 1,
            }}
          >
            <p style={{ margin: 0, color: "#bfe9d7" }}>
              Tidak semua jalan memiliki tanda. Beberapa cukup diingat, bukan
              dilihat.
            </p>
          </div>
        </div>

        <div
          id="rules"
          style={{ marginTop: "1.25rem", opacity: 0.75, fontSize: ".95rem" }}
        >
          <ul style={{ margin: ".5rem 0 0 1rem" }}>
            <li>Gunakan kemampuan observasi, bukan kekuatan.</li>
            <li>
              Hanya mereka yang sabar membaca pola akan menemukan jalannya.
            </li>
            <li>
              Jika kamu ingin mengecek jalur, dengarkan bisik-bisik dari
              endpoint yang jarang dipanggil.
            </li>
            <li>
              Flag berformat <code>POLIJE{"{...}"}</code>.
            </li>
          </ul>
        </div>
      </section>
    </main>
  );
}
