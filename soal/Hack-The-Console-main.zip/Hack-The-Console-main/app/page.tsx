"use client";

import { useState, useRef, useEffect } from "react";
import "./globals.css";

type OutputLine = {
  id: string;
  text: string;
  kind?: "out" | "err" | "info";
};

export default function Page() {
  const [input, setInput] = useState<string>("");
  const [history, setHistory] = useState<OutputLine[]>([]);
  const consoleRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    pushLine(
      "Welcome to CTF Terminal — Hack the Console (advanced). Type 'help' for commands.",
      "info"
    );
    pushLine("", "info");
    pushLine(
      "Tip: try to find hidden endpoints. Some resources are protected.",
      "info"
    );
    document.getElementById("cmdinput")?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // UUIDv4 generator using crypto.getRandomValues (no `any`)
  function uuidv4(): string {
    // create 16 random bytes
    const rnds = new Uint8Array(16);
    if (
      typeof crypto !== "undefined" &&
      typeof crypto.getRandomValues === "function"
    ) {
      crypto.getRandomValues(rnds);
    } else {
      // fallback to Math.random if crypto unavailable (very unlikely in modern browsers)
      for (let i = 0; i < 16; i++) rnds[i] = Math.floor(Math.random() * 256);
    }
    // Per RFC4122 v4: set bits 6-7 of clock_seq_hi_and_reserved to 10
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    // set bits 6-7 of clock_seq_hi_and_reserved to 10
    rnds[8] = (rnds[8] & 0x3f) | 0x80;

    const byteToHex: string[] = [];
    for (let i = 0; i < 256; ++i) {
      byteToHex.push((i + 0x100).toString(16).substr(1));
    }

    return (
      byteToHex[rnds[0]] +
      byteToHex[rnds[1]] +
      byteToHex[rnds[2]] +
      byteToHex[rnds[3]] +
      "-" +
      byteToHex[rnds[4]] +
      byteToHex[rnds[5]] +
      "-" +
      byteToHex[rnds[6]] +
      byteToHex[rnds[7]] +
      "-" +
      byteToHex[rnds[8]] +
      byteToHex[rnds[9]] +
      "-" +
      byteToHex[rnds[10]] +
      byteToHex[rnds[11]] +
      byteToHex[rnds[12]] +
      byteToHex[rnds[13]] +
      byteToHex[rnds[14]] +
      byteToHex[rnds[15]]
    );
  }

  function pushLine(text: string, kind: "out" | "err" | "info" = "out") {
    const id = uuidv4();
    setHistory((h) => [...h, { id, text, kind }]);
    setTimeout(() => {
      consoleRef.current?.scrollTo({
        top: consoleRef.current.scrollHeight,
        behavior: "smooth",
      });
    }, 60);
  }

  async function sendCommand(cmdRaw: string) {
    const cmd = cmdRaw.trim();
    if (!cmd) return;
    pushLine(`$ ${cmd}`, "info");

    try {
      const res = await fetch("/api/cmd", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cmd }),
      });
      const json = await res.json();
      if (res.ok) {
        if (Array.isArray(json.output)) {
          json.output.forEach((line: string) => pushLine(line, "out"));
        } else {
          pushLine(String(json.output ?? JSON.stringify(json)), "out");
        }
      } else {
        pushLine(json.error || "Unknown error", "err");
      }
    } catch (err) {
      pushLine(String(err), "err");
    }
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const cmd = input;
    setInput("");
    sendCommand(cmd);
  }

  return (
    <main style={{ padding: 14 }}>
      <div className="terminal">
        <div className="hdr">
          <div className="logo">BM</div>
          <div>
            <div style={{ fontWeight: 700 }}>CTF Console — Advanced</div>
            <div style={{ fontSize: 13, color: "#9ca3af" }}>
              Semoga Berhasil:v
            </div>
          </div>
        </div>

        <div className="console" ref={consoleRef} id="console">
          {history.map((line) => (
            <div key={line.id} className={`line ${line.kind ?? "out"}`}>
              {line.text}
            </div>
          ))}
        </div>

        <form
          onSubmit={onSubmit}
          className="cmdline"
          aria-label="terminal-form"
          style={{ marginTop: 12 }}
        >
          <input
            id="cmdinput"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Try: help  |  (hint: 'proxy' exists)`}
            autoComplete="off"
            style={{ caretColor: "#93c5fd" }}
          />
          <button type="submit">Run</button>
        </form>
      </div>
    </main>
  );
}
