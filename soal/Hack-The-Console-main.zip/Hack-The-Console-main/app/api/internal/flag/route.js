export async function GET(req) {
  try {
    const marker = req.headers.get("x-internal");
    if (marker !== "1") {
      return new Response(
        JSON.stringify({ error: "Forbidden: not internal" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const FLAG = process.env.FLAG_ROOT;
    if (!FLAG) {
      return new Response(JSON.stringify({ error: "Flag not configured" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(FLAG, {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
