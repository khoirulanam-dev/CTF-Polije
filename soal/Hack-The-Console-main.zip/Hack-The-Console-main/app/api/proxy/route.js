// app/api/proxy/route.js
export async function GET(req) {
  try {
    const url = req.nextUrl.searchParams.get("target") || "";
    if (!url) {
      return new Response(
        JSON.stringify({ error: "missing target parameter" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
    if (!/^https?:\/\//i.test(url)) {
      return new Response(
        JSON.stringify({ error: "invalid target (must be http/https)" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "x-internal": "1",
        Accept: "text/plain, application/json, text/html, */*",
      },
    });

    const text = await response.text();
    // return as text blob (not streaming)
    return new Response(
      JSON.stringify({ status: response.status, body: text }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
