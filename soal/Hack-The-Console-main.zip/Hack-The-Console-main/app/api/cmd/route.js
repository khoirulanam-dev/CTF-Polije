// app/api/cmd/route.js
export async function POST(req) {
  try {
    const { cmd } = await req.json();
    if (typeof cmd !== "string") {
      return new Response(JSON.stringify({ error: "Invalid command" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const argv = cmd.trim().split(/\s+/);
    const base = argv[0]?.toLowerCase() || "";

    const files = {
      "/readme.txt": "Welcome. This is a simulated environment.",
      "/root/notes.txt": "Admin notes: do not expose internal endpoints.",
    };

    function ok(output) {
      return new Response(JSON.stringify({ output }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }
    function err(message, status = 400) {
      return new Response(JSON.stringify({ error: message }), {
        status,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (base === "help") {
      return ok([
        "Available commands:",
        "  help                 Show this help",
        "  ls [path]            List files",
        "  cat <path>           Show file contents",
        "  scan                 Simulate port scan",
        "  connect <ip>         Simulate connect",
        "  whoami               Show user",
        "  hint                 Show subtle hint",
      ]);
    }

    if (base === "ls") {
      const path = argv[1] || "/";
      if (path === "/" || path === ".") {
        return ok(["bin  etc  home  root  var  readme.txt"]);
      }
      if (path === "/root") {
        return ok(
          Object.keys(files)
            .filter((f) => f.startsWith("/root"))
            .map((f) => f.replace("/root/", ""))
        );
      }
      return ok([`(empty) ${path}`]);
    }

    if (base === "whoami") {
      return ok(["guest"]);
    }

    if (base === "scan") {
      return ok(["Scanning 127.0.0.1 ...", "Open ports: 22", "Service: sshd"]);
    }

    if (base === "connect") {
      const ip = argv[1] || "";
      if (!ip) return err("Usage: connect <ip>");
      if (ip === "127.0.0.1") {
        return ok([
          `Connected to ${ip}`,
          "Remote prompt disabled for security.",
        ]);
      }
      return err(`Unable to reach ${ip}`, 502);
    }

    if (base === "cat") {
      const path = argv[1];
      if (!path) return err("Usage: cat <path>");
      if (path === "/root/flag.txt" || path === "/root/flag") {
        // Protected: cannot read directly
        return err(
          "Permission denied: protected resource. (maybe try probing server-side proxy?)",
          403
        );
      }
      if (files[path]) {
        return ok([files[path]]);
      }
      return err(`cat: ${path}: No such file or directory`, 404);
    }

    if (base === "hint") {
      return ok([
        "Hint: There's a proxy endpoint that performs server-side HTTP requests.",
        "Try to discover it and request an internal-only resource.",
      ]);
    }

    return err(`Command not found: ${base}`, 404);
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
